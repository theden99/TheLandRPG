export default {
  "source": "./source",
  "destination": "./build",
  "testDestination": "./__tests__",
  "templates": "./source",
  "sfc": true
}